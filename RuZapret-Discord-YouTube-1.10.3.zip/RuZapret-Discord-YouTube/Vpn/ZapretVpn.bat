@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0ZapretVpn.ps1"
