﻿# ZapretVpn.ps1
# Простой "VPN-режим": выбираете стратегию (Alt) один раз, дальше - одна
# кнопка Подключить/Отключить. При подключении Фильтр игр форсируется в
# TCP+UDP, а Фильтр IP - в режим any (эквивалент пунктов 4 и 5 меню).
# При отключении служба полностью удаляется (как пункт 2 меню).
# Вся сложная логика установки/удаления остаётся в service.bat - этот
# скрипт только выбирает готовые, уже отработанные действия.
# Сборка: JOHN_MARSTN. Движок обхода блокировок: Flowseal (MIT).

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Запрос прав администратора, если их ещё нет ---
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $psi.Verb = "runas"
    try {
        [System.Diagnostics.Process]::Start($psi) | Out-Null
    } catch {}
    exit
}

# Vpn-папка лежит внутри общей папки сборки, service.bat - на уровень выше
$root = Split-Path -Parent $PSScriptRoot
$serviceBat = Join-Path $root "service.bat"

if (-not (Test-Path $serviceBat)) {
    [System.Windows.Forms.MessageBox]::Show(
        "Не найден service.bat рядом с папкой Vpn. Похоже, папку Vpn переместили отдельно от остальной сборки.",
        "Файл не найден") | Out-Null
    exit
}

function Get-StrategyList {
    Get-ChildItem -Path $root -Filter "*.bat" -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -notlike "service*" } |
        Sort-Object { [Regex]::Replace($_.Name, '(\d+)', { $args[0].Value.PadLeft(8, '0') }) } |
        Select-Object -ExpandProperty Name
}

function Get-ZapretStatus {
    $svc = Get-Service -Name zapret -ErrorAction SilentlyContinue
    $proc = Get-Process -Name winws -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running' -and $proc) {
        return @{ Connected = $true; Text = "Подключено"; Color = [System.Drawing.Color]::ForestGreen }
    } else {
        return @{ Connected = $false; Text = "Отключено"; Color = [System.Drawing.Color]::Firebrick }
    }
}

# --- Окно ---

$form = New-Object System.Windows.Forms.Form
$form.Text = "ZapretVpn"
$form.Size = New-Object System.Drawing.Size(360, 300)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$lblTitle = New-Object System.Windows.Forms.Label
$lblTitle.Text = "ZapretVpn"
$lblTitle.Font = New-Object System.Drawing.Font("Segoe UI", 16, [System.Drawing.FontStyle]::Bold)
$lblTitle.Location = New-Object System.Drawing.Point(20, 15)
$lblTitle.Size = New-Object System.Drawing.Size(300, 35)
$form.Controls.Add($lblTitle)

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Font = New-Object System.Drawing.Font("Segoe UI", 11)
$lblStatus.Location = New-Object System.Drawing.Point(20, 55)
$lblStatus.Size = New-Object System.Drawing.Size(300, 25)
$form.Controls.Add($lblStatus)

$lblPick = New-Object System.Windows.Forms.Label
$lblPick.Text = "Стратегия обхода:"
$lblPick.Location = New-Object System.Drawing.Point(20, 95)
$lblPick.Size = New-Object System.Drawing.Size(300, 20)
$form.Controls.Add($lblPick)

$combo = New-Object System.Windows.Forms.ComboBox
$combo.Location = New-Object System.Drawing.Point(20, 118)
$combo.Size = New-Object System.Drawing.Size(300, 25)
$combo.DropDownStyle = "DropDownList"
foreach ($item in (Get-StrategyList)) { [void]$combo.Items.Add($item) }
if ($combo.Items.Count -gt 0) { $combo.SelectedIndex = 0 }
$form.Controls.Add($combo)

$btnToggle = New-Object System.Windows.Forms.Button
$btnToggle.Location = New-Object System.Drawing.Point(20, 160)
$btnToggle.Size = New-Object System.Drawing.Size(300, 55)
$btnToggle.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($btnToggle)

$lblHint = New-Object System.Windows.Forms.Label
$lblHint.Text = "Ядро обхода - разработка Flowseal, лицензия MIT."
$lblHint.Location = New-Object System.Drawing.Point(20, 230)
$lblHint.Size = New-Object System.Drawing.Size(300, 30)
$lblHint.ForeColor = [System.Drawing.Color]::Gray
$lblHint.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$form.Controls.Add($lblHint)

function Refresh-Ui {
    $s = Get-ZapretStatus
    $lblStatus.Text = $s.Text
    $lblStatus.ForeColor = $s.Color
    if ($s.Connected) {
        $btnToggle.Text = "Отключить"
        $combo.Enabled = $false
    } else {
        $btnToggle.Text = "Подключить"
        $combo.Enabled = $true
    }
}

$btnToggle.Add_Click({
    $btnToggle.Enabled = $false
    $s = Get-ZapretStatus

    if ($s.Connected) {
        $lblStatus.Text = "Отключаю..."
        $lblStatus.ForeColor = [System.Drawing.Color]::DarkOrange
        Start-Process -FilePath $serviceBat -ArgumentList "admin vpn_disconnect" -Wait -WindowStyle Minimized
    } else {
        if ($combo.SelectedItem) {
            $lblStatus.Text = "Подключаю..."
            $lblStatus.ForeColor = [System.Drawing.Color]::DarkOrange
            $strategy = [string]$combo.SelectedItem
            $argStr = 'admin vpn_connect "' + $strategy + '"'
            Start-Process -FilePath $serviceBat -ArgumentList $argStr -Wait -WindowStyle Minimized
        }
    }

    Start-Sleep -Seconds 2
    Refresh-Ui
    $btnToggle.Enabled = $true
})

Refresh-Ui
[void]$form.ShowDialog()
