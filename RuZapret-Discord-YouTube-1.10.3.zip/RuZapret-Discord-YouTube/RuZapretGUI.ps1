﻿# ZapretGUI.ps1
# Графическая панель поверх service.bat. Вся сложная логика (установка
# стратегий, диагностика, автоподбор) остаётся в service.bat и не
# дублируется здесь - это окно только удобно её запускает плюс даёт
# быстрый доступ к статусу и списку сайтов напрямую.
# Сборка: JOHN_MARSTN. Движок обхода блокировок: Flowseal (MIT).

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName Microsoft.VisualBasic

# --- Запрос прав администратора, если их ещё нет ---
$currentPrincipal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
$isAdmin = $currentPrincipal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    $psi = New-Object System.Diagnostics.ProcessStartInfo
    $psi.FileName = "powershell.exe"
    $psi.Arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    $psi.Verb = "runas"
    try {
        [System.Diagnostics.Process]::Start($psi) | Out-Null
    } catch {}
    exit
}

$root = $PSScriptRoot
$serviceBat = Join-Path $root "service.bat"

# --- Вспомогательные функции ---

function Get-ZapretStatus {
    $svc = Get-Service -Name zapret -ErrorAction SilentlyContinue
    $proc = Get-Process -Name winws -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running' -and $proc) {
        return @{ Text = "Обход РАБОТАЕТ"; Color = [System.Drawing.Color]::ForestGreen }
    } elseif ($svc) {
        return @{ Text = "Служба установлена, но обход не запущен"; Color = [System.Drawing.Color]::DarkOrange }
    } else {
        return @{ Text = "Служба не установлена"; Color = [System.Drawing.Color]::Firebrick }
    }
}

function Open-ServiceBat {
    param([string]$Note)
    if ($Note) {
        [System.Windows.Forms.MessageBox]::Show($Note, "Открываю полное меню") | Out-Null
    }
    Start-Process -FilePath $serviceBat -WorkingDirectory $root
}

function Add-ZapretSite {
    param([string]$Root)

    $listFile = Join-Path $Root "lists\list-general-user.txt"
    $enc = [System.Text.Encoding]::GetEncoding(866)

    $prompt = "Введите домен без http(s):// и www, например example.com" + "`r`n" + "Чтобы удалить сайт - впишите его с минусом впереди: -example.com"
    $domain = [Microsoft.VisualBasic.Interaction]::InputBox($prompt, "Добавить или убрать сайт", "")
    if ([string]::IsNullOrWhiteSpace($domain)) { return }

    $domain = $domain.Trim()
    $domain = $domain -replace '^https?://', ''
    $domain = $domain -replace '^www\.', ''
    $domain = $domain -replace '\s', ''

    if ($domain.StartsWith('-')) {
        $remove = ($domain.Substring(1) -split '/')[0]
        if ($remove -eq '') { return }
        if (Test-Path $listFile) {
            $lines = [System.IO.File]::ReadAllLines($listFile, $enc)
            $filtered = $lines | Where-Object { $_.Trim().ToLower() -ne $remove.ToLower() }
            $newText = ($filtered -join "`r`n") + "`r`n"
            [System.IO.File]::WriteAllText($listFile, $newText, $enc)
        }
        [System.Windows.Forms.MessageBox]::Show("Удалено (если было в списке): $remove", "Готово") | Out-Null
    } else {
        $domain = ($domain -split '/')[0]
        if ($domain -notmatch '^[a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$') {
            [System.Windows.Forms.MessageBox]::Show("Похоже, это не домен: $domain", "Проверьте формат") | Out-Null
            return
        }
        $existing = @()
        if (Test-Path $listFile) { $existing = [System.IO.File]::ReadAllLines($listFile, $enc) }
        if ($existing -contains $domain) {
            [System.Windows.Forms.MessageBox]::Show("Этот домен уже есть в списке.", "Уже добавлено") | Out-Null
        } else {
            [System.IO.File]::AppendAllText($listFile, "$domain`r`n", $enc)
            [System.Windows.Forms.MessageBox]::Show("Добавлено: $domain", "Готово") | Out-Null
        }
    }

    $svc = Get-Service -Name zapret -ErrorAction SilentlyContinue
    if ($svc -and $svc.Status -eq 'Running') {
        $result = [System.Windows.Forms.MessageBox]::Show(
            "Перезапустить обход сейчас, чтобы применить изменения?",
            "Перезапуск",
            [System.Windows.Forms.MessageBoxButtons]::YesNo)
        if ($result -eq [System.Windows.Forms.DialogResult]::Yes) {
            Restart-Service -Name zapret -Force -ErrorAction SilentlyContinue
        }
    }
}

# --- Окно ---

$form = New-Object System.Windows.Forms.Form
$form.Text = "RuZapret - панель управления (сборка JOHN_MARSTN)"
$form.Size = New-Object System.Drawing.Size(430, 400)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$lblStatus = New-Object System.Windows.Forms.Label
$lblStatus.Location = New-Object System.Drawing.Point(20, 20)
$lblStatus.Size = New-Object System.Drawing.Size(380, 30)
$lblStatus.Font = New-Object System.Drawing.Font("Segoe UI", 12, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblStatus)

function Refresh-Status {
    $s = Get-ZapretStatus
    $lblStatus.Text = $s.Text
    $lblStatus.ForeColor = $s.Color
}

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Text = "Обновить статус"
$btnRefresh.Location = New-Object System.Drawing.Point(20, 60)
$btnRefresh.Size = New-Object System.Drawing.Size(180, 35)
$btnRefresh.Add_Click({ Refresh-Status })
$form.Controls.Add($btnRefresh)

$btnStart = New-Object System.Windows.Forms.Button
$btnStart.Text = "Запустить обход"
$btnStart.Location = New-Object System.Drawing.Point(210, 60)
$btnStart.Size = New-Object System.Drawing.Size(180, 35)
$btnStart.Add_Click({
    $svc = Get-Service -Name zapret -ErrorAction SilentlyContinue
    if ($svc) {
        Start-Service -Name zapret -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 1
        Refresh-Status
    } else {
        Open-ServiceBat "Служба ещё не установлена. Открою полное меню - выберите пункт 1 (или 16 для автоподбора)."
    }
})
$form.Controls.Add($btnStart)

$btnStop = New-Object System.Windows.Forms.Button
$btnStop.Text = "Остановить обход"
$btnStop.Location = New-Object System.Drawing.Point(20, 105)
$btnStop.Size = New-Object System.Drawing.Size(180, 35)
$btnStop.Add_Click({
    Stop-Service -Name zapret -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 1
    Refresh-Status
})
$form.Controls.Add($btnStop)

$btnAddSite = New-Object System.Windows.Forms.Button
$btnAddSite.Text = "Добавить / убрать сайт"
$btnAddSite.Location = New-Object System.Drawing.Point(210, 105)
$btnAddSite.Size = New-Object System.Drawing.Size(180, 35)
$btnAddSite.Add_Click({ Add-ZapretSite -Root $root })
$form.Controls.Add($btnAddSite)

$btnAuto = New-Object System.Windows.Forms.Button
$btnAuto.Text = "Автоподбор стратегии"
$btnAuto.Location = New-Object System.Drawing.Point(20, 150)
$btnAuto.Size = New-Object System.Drawing.Size(180, 35)
$btnAuto.Add_Click({ Open-ServiceBat "Открою консольное меню - там выберите пункт 16 (Автоподбор стратегии)." })
$form.Controls.Add($btnAuto)

$btnDiag = New-Object System.Windows.Forms.Button
$btnDiag.Text = "Диагностика"
$btnDiag.Location = New-Object System.Drawing.Point(210, 150)
$btnDiag.Size = New-Object System.Drawing.Size(180, 35)
$btnDiag.Add_Click({ Open-ServiceBat "Открою консольное меню - там выберите пункт 11 (Диагностика)." })
$form.Controls.Add($btnDiag)

$btnFullMenu = New-Object System.Windows.Forms.Button
$btnFullMenu.Text = "Полное меню (все функции)"
$btnFullMenu.Location = New-Object System.Drawing.Point(20, 195)
$btnFullMenu.Size = New-Object System.Drawing.Size(370, 35)
$btnFullMenu.Add_Click({ Open-ServiceBat })
$form.Controls.Add($btnFullMenu)

$btnAbout = New-Object System.Windows.Forms.Button
$btnAbout.Text = "О программе"
$btnAbout.Location = New-Object System.Drawing.Point(20, 240)
$btnAbout.Size = New-Object System.Drawing.Size(370, 35)
$btnAbout.Add_Click({
    $text = "В основе - движок обхода блокировок Flowseal (MIT)." + "`r`n`r`n" +
            "Сверху добавлено (сборка JOHN_MARSTN): автоподбор рабочей " +
            "стратегии, добавление и удаление сайтов из меню и из этого " +
            "окна, автоперезапуск после правок, бэкап и восстановление " +
            "списков, расширенный список сайтов (Telegram, WhatsApp, " +
            "Instagram, Twitter/X, Twitch, Reddit, Steam, Netflix, GitHub " +
            "и другие), усиленная диагностика, вот это графическое окно " +
            "поверх консольного меню."
    [System.Windows.Forms.MessageBox]::Show($text, "О программе") | Out-Null
})
$form.Controls.Add($btnAbout)

$lblHint = New-Object System.Windows.Forms.Label
$lblHint.Text = "Ядро обхода блокировок - разработка Flowseal, лицензия MIT."
$lblHint.Location = New-Object System.Drawing.Point(20, 290)
$lblHint.Size = New-Object System.Drawing.Size(380, 40)
$lblHint.ForeColor = [System.Drawing.Color]::Gray
$lblHint.Font = New-Object System.Drawing.Font("Segoe UI", 8)
$form.Controls.Add($lblHint)

Refresh-Status
[void]$form.ShowDialog()
