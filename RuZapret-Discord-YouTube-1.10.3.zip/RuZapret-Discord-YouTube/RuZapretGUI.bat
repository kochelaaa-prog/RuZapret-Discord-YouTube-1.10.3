@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0RuZapretGUI.ps1"
